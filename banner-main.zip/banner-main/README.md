# banner
Código de html para aula de Pensamento Computacional.
